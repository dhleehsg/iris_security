function [ Token ] = IFOhashingToken( BioCode,PIN,params )

rng(PIN);

width = size(BioCode,2);

M = params(2);
P = params(3);

    
theta_set = zeros(M,P,width);
for m_ind = 1:M
    for p_ind = 1:P
        theta_set(m_ind,p_ind,:) = randperm(width);
    end
end
Token.t1 = theta_set;


end

