function [ template ] = Biohashing( BioCode,Token,params )

threshold = 0;
normbio = BioCode(:)/norm(double(BioCode(:))); % normalized biocode
template = Token.t1'*normbio>=threshold;

end

