function [ Token ] = SRPToken( BioCode,PIN,params )

height = size(BioCode,1);
width = size(BioCode,2);
M = params(1);
nblock = params(2);
nfeatures = height*width;
nfeature_per_block = nfeatures/nblock;

rng(PIN);
keyMatrix = random('norm',0,1,[nfeature_per_block M+1]);
Token.t1 = orth(keyMatrix); % projection matrix


end

