function [ Token ] = BiohashingToken( BioCode,PIN,params )

height = size(BioCode,1);
width = size(BioCode,2);
M = params;

rng(PIN);
keyMatrix = random('norm',0,1,[height*width M+1]);
Token.t1 = orth(keyMatrix); % projection matrix

end

