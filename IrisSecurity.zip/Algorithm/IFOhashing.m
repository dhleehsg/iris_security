function [ template ] = IFOhashing( BioCode,Token,params )

K = params(1);
M = params(2);
P = params(3);
tau = params(4);

    
n1 = size(BioCode,1);
hashcode = zeros(n1,M);

%%% IFO hashing fast code
for m_ind = 1:M
    if P == 1
        temp = BioCode(:,Token.t1(m_ind,1,1:K));
    elseif P == 2
        temp = BioCode(:,Token.t1(m_ind,1,1:K)) & BioCode(:,Token.t1(m_ind,2,1:K));
    elseif P == 3
        temp = BioCode(:,Token.t1(m_ind,1,1:K)) & BioCode(:,Token.t1(m_ind,2,1:K)) & BioCode(:,Token.t1(m_ind,3,1:K));
    elseif P == 4
        temp = BioCode(:,Token.t1(m_ind,1,1:K)) & BioCode(:,Token.t1(m_ind,2,1:K)) & BioCode(:,Token.t1(m_ind,3,1:K)) & BioCode(:,Token.t1(m_ind,4,1:K));
    elseif P == 5
        temp = BioCode(:,Token.t1(m_ind,1,1:K)) & BioCode(:,Token.t1(m_ind,2,1:K)) & BioCode(:,Token.t1(m_ind,3,1:K)) & BioCode(:,Token.t1(m_ind,4,1:K)) & BioCode(:,Token.t1(m_ind,5,1:K));
    elseif P == 6
        temp = BioCode(:,Token.t1(m_ind,1,1:K)) & BioCode(:,Token.t1(m_ind,2,1:K)) & BioCode(:,Token.t1(m_ind,3,1:K)) & BioCode(:,Token.t1(m_ind,4,1:K)) & BioCode(:,Token.t1(m_ind,5,1:K)) & BioCode(:,Token.t1(m_ind,6,1:K));
    end
    for n1_ind = 1:n1
        ind_first = find(temp(n1_ind,:),1);
        if ind_first > 0
            hashcode(n1_ind,m_ind) = mod(ind_first,K-tau);
        end
    end
end


%% IFO hashing direct code
%     for n1_ind = 1:n1
%         for m_ind = 1:M
%             biorowvec1 = BioCode(n1_ind,:);
%             temp = ones(size(biorowvec1));
%             % Hadamard product of P iterations
% 
%             if P == 3
%                 temp = biorowvec1(Token.t1(m_ind,1,:)) & biorowvec1(Token.t1(m_ind,2,:)) & biorowvec1(Token.t1(m_ind,3,:));
%             end
% 
%             temp = temp(1:K);
%             ind_first = find(temp,1);
%             if ind_first > 0
%                 hashcode(n1_ind,m_ind) = mod(ind_first,K-tau);
%             end            
%         end
%     end 
template = hashcode;
end

