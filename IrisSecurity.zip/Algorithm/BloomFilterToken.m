function [ Token ] = BloomFilterToken( BioCode,PIN,params )

height = size(BioCode,1);

rng(PIN);
Token.t1 = randperm(height);

H = 8; % word size (the height of a block)
N = 2^H; % % a bloom filter size

tmpbi = de2bi(floor(rand(1)*N));
len_tmpbi = length(tmpbi);
if H > len_tmpbi
    for j = 1:(H-len_tmpbi)
        tmpbi = [tmpbi 0];
    end            
end
tmpbi = fliplr(tmpbi);
Token.t2 = tmpbi';  

end

