function [ template ] = BlockRemapping( BioCode,Token,params )

height = size(BioCode,1);
width = size(BioCode,2);
nheight_block = params(1);
nwidth_block = params(2);
height_block = height/nheight_block;            
width_block = width/nwidth_block;        

% rng(PIN);
% 
% rp = randperm(nblocks);
% seq = zeros(nblocks,1);
% 
% for i = 1:nblocks-ndrop_block;            
%     seq(rp(i)) = i;
% end
% for i = nblocks-ndrop_block+1:nblocks;            
%     seq(rp(i)) = randi(nblocks-ndrop_block);
% end
% Token.t1 = seq;            

bioblock = mat2cell(BioCode,height_block*ones(1,nheight_block),width_block*ones(1,nwidth_block)); 
bioreblock = bioblock(Token.t1);
bioreblock = reshape(bioreblock,[nheight_block nwidth_block]);
template = cell2mat(bioreblock);
end

