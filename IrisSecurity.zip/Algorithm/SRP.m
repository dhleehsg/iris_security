function [ template ] = SRP( BioCode,Token,params )

height = size(BioCode,1);
width = size(BioCode,2);
M = params(1);
nblock = params(2);
nfeatures = height*width;
nfeature_per_block = nfeatures/nblock;

threshold = 0;
bio = cell(nblock,1);
hashingbio1 = cell(nblock,1);
for nb = 1:nblock
    bio{nb} = BioCode(1+nfeature_per_block*(nb-1):nfeature_per_block*nb)/norm(double(BioCode(1+nfeature_per_block*(nb-1):nfeature_per_block*nb)));
    bio{nb} = bio{nb}(:);
    hashingbio1{nb} = Token.t1'*bio{nb}>=threshold;   
end
template = cat(1,hashingbio1{:});

end

