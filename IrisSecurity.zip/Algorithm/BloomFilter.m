function [ template ] = BloomFilter( BioCode,Token,params )

% height = size(BioCode,1);
% 
% rng(PIN);
% Token.t1 = randperm(height);
% 
% 
K = params;
W = size(BioCode,2); % feature width
H = 8; % word size (the height of a block)
L = W/K; % feature block width
N = 2^H; % % a bloom filter size
% 
% tmpbi = de2bi(floor(rand(1)*N));
% len_tmpbi = length(tmpbi);
% if H > len_tmpbi
%     for j = 1:(H-len_tmpbi)
%         tmpbi = [tmpbi 0];
%     end            
% end
% tmpbi = fliplr(tmpbi);
% Token.t2 = tmpbi';  
    
template = zeros(N,K*2);

for ind_k = 1:K
    bio1 = BioCode(Token.t1(1:H),(1+(ind_k-1)*L):ind_k*L)';
    tok = repmat(Token.t2',L,1);
    tn = bi2de(xor(bio1,tok));
    template(tn+1,ind_k) = 1;
    bio1 = BioCode(Token.t1(H+1:H*2),(1+(ind_k-1)*L):ind_k*L)';
    tn = bi2de(xor(bio1,tok));
    template(tn+1,K+ind_k) = 1;        
end


end

