function [ Token ] = BlockRemappingToken( BioCode,PIN,params )

nheight_block = params(1);
nwidth_block = params(2);
ndrop_block = params(3);
nblocks = nheight_block*nwidth_block;   

rng(PIN);

rp = randperm(nblocks);
seq = zeros(nblocks,1);

for i = 1:nblocks-ndrop_block;            
    seq(rp(i)) = i;
end
for i = nblocks-ndrop_block+1:nblocks;            
    seq(rp(i)) = randi(nblocks-ndrop_block);
end
Token.t1 = seq;  

end

