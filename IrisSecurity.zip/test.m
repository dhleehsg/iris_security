% sample test scrpit for iris security
% based on paper : 'Cancelable Iris Biometrics for Using Noise Embedding'
% written by D.H. Lee (Seoul Nat'l University in South Korea)
% dhlee@ispl.snu.ac.kr

addpath('./Function');

%%% load BioCode database
%%% BioCode is cell type with binary iriscode (20x512 size in CASIA V3
%%% database)
%%% for example, BioCode is defined like this using CASIA V3 database in
%%% our paper
% BioCode = cell(nbiocode,1);
% BioCode{1} = iriscode1_c1; % a iriscode of class 1
% BioCode{2} = iriscode2_c1; % a iriscode of class 1
% BioCode{3} = iriscode3_c1; % a iriscode of class 1
% BioCode{4} = iriscode4_c1; % a iriscode of class 1
% BioCode{5} = iriscode5_c1; % a iriscode of class 1
% BioCode{6} = iriscode6_c1; % a iriscode of class 1
% BioCode{7} = iriscode7_c1; % a iriscode of class 1
% BioCode{8} = iriscode1_c2; % a iriscode of class 2
% BioCode{9} = iriscode2_c2; % a iriscode of class 2
% etc....
datapath = './../../CASIA_v3_interval_DB/data/botheye/usit/wahet/512x20/BioCode.mat';
load(datapath);

b1 = BioCode{1}; % class 1
b2 = BioCode{2}; % class 1
b3 = BioCode{3}; % class 1
b5 = BioCode{5}; % class 1
b7 = BioCode{7}; % class 1
b8 = BioCode{8}; % class 2
b9 = BioCode{9}; % class 2
b10 = BioCode{10}; % class 2
b11 = BioCode{11}; % class 2
b12 = BioCode{12}; % class 2

%%% use 'enrollment' function to enroll an iriscode or training iriscodes
%%% use 'authentication' function to authenticate query iriscode

%%% Algorithm : Biohashing
disp('Biohashing');
params = 512; % bit string length
t1 = enrollment(b1,1,'Biohashing',params);
authentication(b2,1,t1,'Biohashing',params); % GE score calculation
authentication(b8,2,t1,'Biohashing',params); % IM score calculation
authentication(b8,1,t1,'Biohashing',params); % PG1 score calculation
authentication(b1,2,t1,'Biohashing',params); % PG2 score calculation
%%% GE,IM,PG1, and PG2 terms are descripted in paper

%%% Algorithm : SRP
disp('SRP');
params = [512,8];  % [bit string length, the number of sectors]
t1 = enrollment(b1,1,'SRP',params);
authentication(b2,1,t1,'SRP',params); % GE score calculation
authentication(b8,2,t1,'SRP',params); % IM score calculation
authentication(b8,1,t1,'SRP',params); % PG1 score calculation
authentication(b1,2,t1,'SRP',params); % PG2 score calculation

%%% Algorithm : BloomFilter
disp('BloomFilter');
params = 16; % number of blocks
t1 = enrollment(b1,1,'BloomFilter',params);
authentication(b2,1,t1,'BloomFilter',params); % GE score calculation
authentication(b8,2,t1,'BloomFilter',params); % IM score calculation
authentication(b8,1,t1,'BloomFilter',params); % PG1 score calculation
authentication(b1,2,t1,'BloomFilter',params); % PG2 score calculation

%%% Algorithm : BlockRemapping
%%% parameters
%%% 'nheight_block' : number of height block
%%% 'nwidth_block' : number of width block
%%% 'ndrop_block' : dropped and copied block number
disp('BlockRemapping');
params = [2,32,56];
t1 = enrollment(b1,1,'BlockRemapping',params);
authentication(b2,1,t1,'BlockRemapping',params); % GE score calculation
authentication(b8,2,t1,'BlockRemapping',params); % IM score calculation
authentication(b8,1,t1,'BlockRemapping',params); % PG1 score calculation
authentication(b1,2,t1,'BlockRemapping',params); % PG2 score calculation

%%% Algorithm : IFOhashing
%%% parameters
%%% K : window size
%%% m : number of iterations
%%% P : order of Hadamard matrix
%%% tau : security threshold
disp('IFOhashing');
params = [50,50,3,0]; % [K, m, P, tau] in their paper
t1 = enrollment(b1,1,'IFOhashing',params);
authentication(b2,1,t1,'IFOhashing',params); % GE score calculation
authentication(b8,2,t1,'IFOhashing',params); % IM score calculation
authentication(b8,1,t1,'IFOhashing',params); % PG1 score calculation
authentication(b1,2,t1,'IFOhashing',params); % PG2 score calculation

%%% Algorithm : Proposed algorithm
%%% parameters
%%% h : the number of rows of RRP matrix
%%% q : the order of Hadamard matrix
%%% r : the number of iterations
disp('Proposed algorithm');
params = [10,3,12];
trainset = cell(15,1);
trainset{1} = BioCode{1};
trainset{2} = BioCode{3};
trainset{3} = BioCode{4};
trainset{4} = BioCode{5};
trainset{5} = BioCode{1};
trainset{6} = BioCode{3};
trainset{7} = BioCode{4};
trainset{8} = BioCode{5};
trainset{9} = BioCode{1};
trainset{10} = BioCode{3};
trainset{11} = BioCode{4};
trainset{12} = BioCode{5};
trainset{13} = BioCode{1};
trainset{14} = BioCode{3};
trainset{15} = BioCode{4};
% trainset{16} = BioCode{5};
% trainset{17} = BioCode{1};
% trainset{18} = BioCode{3};
% trainset{19} = BioCode{4};
% trainset{20} = BioCode{5};
t1 = enrollment(trainset,1,'Prop',params);
authentication(b2,1,t1,'Prop',params); % GE score calculation
authentication(b8,2,t1,'Prop',params); % IM score calculation
authentication(b8,1,t1,'Prop',params); % PG1 score calculation
authentication(b1,2,t1,'Prop',params); % PG2 score calculation