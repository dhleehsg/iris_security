function template = enrollment( BioCode,PIN,alg,params )
% BioCode : input iriscode
% PIN : pseudo indentification number
% alg : algorithm name 
%      'Biohashing','SRP','BlockRemapping','BloomFilter','IFOhashing','Prop'
% params : parameters
% template : output template

addpath('./Algorithm');

if nargin ~= 4
    error('The number of parameters should be four in the enrollment.');
end
tic
if strcmp(alg,'Biohashing')
    token = BiohashingToken(BioCode,PIN,params); timed1 = toc;tic;
    template = Biohashing(BioCode,token,params);
elseif strcmp(alg,'SRP')
    token = SRPToken(BioCode,PIN,params); timed1 = toc;tic;
    template = SRP(BioCode,token,params);
elseif strcmp(alg,'BlockRemapping')
    token = BlockRemappingToken(BioCode,PIN,params); timed1 = toc;tic;
    template = BlockRemapping(BioCode,token,params);
elseif strcmp(alg,'BloomFilter')
    token = BloomFilterToken(BioCode,PIN,params); timed1 = toc;tic;
    template = BloomFilter(BioCode,token,params);
elseif strcmp(alg,'IFOhashing')
    token = IFOhashingToken(BioCode,PIN,params); timed1 = toc;tic;
    template = IFOhashing(BioCode,token,params);
elseif strcmp(alg,'Prop')
    token = PropToken(BioCode,PIN,params,0); timed1 = toc;tic;
    template = Prop(BioCode,token,params,0);
else
    error('Select appropriate algorithm');
end
timed2 = toc;
fprintf('Computing CB token(key) time: %6.4f sec, Enrollment time: %6.4f sec, total: %6.4f sec\n',timed1,timed2,timed1+timed2);

end

