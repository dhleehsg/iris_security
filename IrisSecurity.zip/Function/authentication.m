function authentication( BioCode,PIN,DBtemplate,alg,params )
% BioCode : input iriscode
% PIN : pseudo indentification number
% DBtemplate : input reference template from database
% alg : algorithm name 
%      'Biohashing','SRP','BlockRemapping','BloomFilter','IFOhashing','Prop'
% params : parameters

addpath('./Algorithm');

if nargin ~= 5
    error('The number of parameters should be five in the authentication.');
end
tic
if strcmp(alg,'Biohashing')
    token = BiohashingToken(BioCode,PIN,params); timed1 = toc;tic;
    minscore = 1;
    for k = -8:1:8
        BioCode_shift = circshift(BioCode,k,2);        
        template = Biohashing(BioCode_shift,token,params);
        score = NormHammingDist(template,DBtemplate);
        if score < minscore
            minscore = score;
        end 
    end            
elseif strcmp(alg,'SRP')
    token = SRPToken(BioCode,PIN,params); timed1 = toc;tic;
    minscore = 1;
    for k = -8:1:8 
        BioCode_shift = circshift(BioCode,k,2);       
        template = SRP(BioCode_shift,token,params);
        score = NormHammingDist(template,DBtemplate);
        if score < minscore
            minscore = score;
        end 
    end    
elseif strcmp(alg,'BlockRemapping')
    token = BlockRemappingToken(BioCode,PIN,params); timed1 = toc;tic;
    minscore = 1;
    for k = -8:1:8    
        BioCode_shift = circshift(BioCode,k,2);    
        template = BlockRemapping(BioCode_shift,token,params);
        score = NormHammingDist(template,DBtemplate);
        if score < minscore
            minscore = score;
        end 
    end        
elseif strcmp(alg,'BloomFilter') % bloom filter is alignment-free
    token = BloomFilterToken(BioCode,PIN,params); timed1 = toc;tic;
    template = BloomFilter(BioCode,token,params);
    minscore = BloomFilterDist(template,DBtemplate,params);
elseif strcmp(alg,'IFOhashing')
    token = IFOhashingToken(BioCode,PIN,params); timed1 = toc;tic;
    minscore = 1;
    for k = -8:1:8
        BioCode_shift = circshift(BioCode,k,2);
        template = IFOhashing(BioCode_shift,token,params);
        score = dissimilarity(template,DBtemplate);
        if score < minscore
            minscore = score;
        end 
    end
elseif strcmp(alg,'Prop')
    token = PropToken(BioCode,PIN,params,1); timed1 = toc;tic;
    minscore = 1;
    for k = -8:1:8
        BioCode_shift = circshift(BioCode,k,2);
        template = Prop(BioCode_shift,token,params,1);
        score = dissimilarity(template,DBtemplate);
        if score < minscore
            minscore = score;
        end 
    end
else
    error('Select appropriate algorithm');
end
timed2 = toc;
fprintf('Computing CB token(key) time: %6.4f sec, Authentication time: %6.4f sec, total: %6.4f sec, Score: %.4f\n',timed1,timed2,timed1+timed2,minscore);
end

function score = NormHammingDist(target,ref)
    if((size(ref,1) ~= size(target,1)) || (size(ref,2) ~= size(target,2)) || (numel(ref) ~= numel(target)))
        error('size of two templates should be the same');
    end
    C = xor(logical(target),logical(ref));

    totalbits = (size(ref,1)*size(ref,2));

    bitsdiff = sum(sum(C==1));

    score = bitsdiff / totalbits;
   
end

function score = BloomFilterDist(target,ref,params)
    if((size(ref,1) ~= size(target,1)) || (size(ref,2) ~= size(target,2)) || (numel(ref) ~= numel(target)))
        error('size of two templates should be the same');
    end

    K = params;
    sum_DS = 0;
    for ind_k = 1:K*2
         sum_DS = sum_DS + sum(xor(target(:,ind_k),ref(:,ind_k)))/(sum(target(:,ind_k))+sum(ref(:,ind_k)));
    end
    sum_DS = sum_DS / (2*K);
    score = sum_DS;
end

function score = dissimilarity(target,ref)
    if((size(ref,1) ~= size(target,1)) || (size(ref,2) ~= size(target,2)) || (numel(ref) ~= numel(target)))
        error('size of two templates should be the same');
    end
    B_x1 = target>0;
    B_x2 = ref>0;
    B_union = B_x1 & B_x2;
    Q_x = target == ref;
    score = 1-sum(sum(B_union & Q_x))/sum(sum(B_union));
end